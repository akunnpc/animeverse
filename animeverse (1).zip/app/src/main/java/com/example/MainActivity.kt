package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.database.AppDatabase
import com.example.navigation.AnimeNavHost
import com.example.repository.AnimeRepositoryImpl
import com.example.theme.AnimeVerseTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Edge-to-edge support for modern immersive Android layouts
        enableEdgeToEdge()
        
        // Instantiate Local Room Database and Repository
        val database = AppDatabase.getDatabase(applicationContext)
        val favoriteDao = database.favoriteDao()
        val repository = AnimeRepositoryImpl(favoriteDao)

        setContent {
            AnimeVerseTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    AnimeNavHost(repository = repository)
                }
            }
        }
    }
}
