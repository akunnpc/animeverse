package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.Media
import com.example.repository.AnimeRepository
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

sealed interface SearchUiState {
    object Idle : SearchUiState
    object Loading : SearchUiState
    data class Success(val results: List<Media>) : SearchUiState
    data class Error(val message: String) : SearchUiState
}

@OptIn(FlowPreview::class)
class SearchViewModel(private val repository: AnimeRepository) : ViewModel() {
    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedFilter = MutableStateFlow("ALL") // ALL, ANIME, MANGA, MANHWA, MANHUA
    val selectedFilter = _selectedFilter.asStateFlow()

    private var searchJob: Job? = null

    init {
        // Set up real-time search with a debounce to prevent API rate limits
        viewModelScope.launch {
            _searchQuery
                .debounce(500)
                .distinctUntilChanged()
                .collect { query ->
                    performSearch(query, _selectedFilter.value)
                }
        }
    }

    fun onQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun onFilterSelected(filter: String) {
        _selectedFilter.value = filter
        performSearch(_searchQuery.value, filter)
    }

    fun retrySearch() {
        performSearch(_searchQuery.value, _selectedFilter.value)
    }

    private fun performSearch(query: String, filter: String) {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            // If both search query is empty and filter is "ALL", let's show an idle empty state or trending search
            if (query.isBlank() && filter == "ALL") {
                _uiState.value = SearchUiState.Idle
                return@launch
            }

            _uiState.value = SearchUiState.Loading
            try {
                val type = when (filter) {
                    "ANIME" -> "ANIME"
                    "MANGA", "MANHWA", "MANHUA" -> "MANGA"
                    else -> null // ALL
                }

                val country = when (filter) {
                    "MANGA" -> "JP"
                    "MANHWA" -> "KR"
                    "MANHUA" -> "CN"
                    else -> null
                }

                val results = repository.searchMedia(
                    query = query,
                    type = type,
                    countryOfOrigin = country,
                    page = 1,
                    perPage = 30
                )
                _uiState.value = SearchUiState.Success(results)
            } catch (e: Exception) {
                _uiState.value = SearchUiState.Error(e.localizedMessage ?: "Gagal memuat hasil pencarian.")
            }
        }
    }
}
