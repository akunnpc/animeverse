package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.Media
import com.example.repository.AnimeRepository
import com.example.utils.SeasonUtils
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface HomeUiState {
    object Loading : HomeUiState
    data class Success(
        val trending: List<Media>,
        val popular: List<Media>,
        val seasonal: List<Media>,
        val topRated: List<Media>,
        val currentSeasonLabel: String,
        val currentYear: Int
    ) : HomeUiState
    data class Error(val message: String) : HomeUiState
}

class HomeViewModel(private val repository: AnimeRepository) : ViewModel() {
    private val _uiState = MutableStateFlow<HomeUiState>(HomeUiState.Loading)
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadHomeData()
    }

    fun loadHomeData() {
        viewModelScope.launch {
            _uiState.value = HomeUiState.Loading
            try {
                val currentSeason = SeasonUtils.getCurrentSeason()
                val currentYear = SeasonUtils.getCurrentYear()
                val seasonName = currentSeason.name // "WINTER", "SPRING", etc.

                // Perform calls concurrently
                val trendingDeferred = async { repository.getTrending(type = null, page = 1, perPage = 10) }
                val popularDeferred = async { repository.getPopular(type = null, page = 1, perPage = 10) }
                val seasonalDeferred = async { repository.getSeasonal(currentYear, seasonName, page = 1, perPage = 10) }
                val topRatedDeferred = async { repository.getTopRated(type = null, page = 1, perPage = 10) }

                _uiState.value = HomeUiState.Success(
                    trending = trendingDeferred.await(),
                    popular = popularDeferred.await(),
                    seasonal = seasonalDeferred.await(),
                    topRated = topRatedDeferred.await(),
                    currentSeasonLabel = SeasonUtils.getSeasonLabel(currentSeason),
                    currentYear = currentYear
                )
            } catch (e: Exception) {
                _uiState.value = HomeUiState.Error(e.localizedMessage ?: "Gagal memuat data. Periksa koneksi internet Anda.")
            }
        }
    }
}
