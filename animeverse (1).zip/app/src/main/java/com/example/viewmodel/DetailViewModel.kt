package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.Media
import com.example.repository.AnimeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed interface DetailUiState {
    object Loading : DetailUiState
    data class Success(val media: Media) : DetailUiState
    data class Error(val message: String) : DetailUiState
}

class DetailViewModel(private val repository: AnimeRepository) : ViewModel() {
    private val _uiState = MutableStateFlow<DetailUiState>(DetailUiState.Loading)
    val uiState: StateFlow<DetailUiState> = _uiState.asStateFlow()

    private val _isFavorite = MutableStateFlow(false)
    val isFavorite: StateFlow<Boolean> = _isFavorite.asStateFlow()

    private var currentMediaId: Int? = null

    fun loadMediaDetail(id: Int) {
        currentMediaId = id

        // Listen to local Room database for real-time favorite status changes
        viewModelScope.launch {
            repository.isFavoriteFlow(id).collectLatest { isFav ->
                _isFavorite.value = isFav
            }
        }

        // Fetch detailed data from remote API
        fetchDetail()
    }

    fun fetchDetail() {
        val id = currentMediaId ?: return
        viewModelScope.launch {
            _uiState.value = DetailUiState.Loading
            try {
                val media = repository.getMediaDetail(id)
                if (media != null) {
                    _uiState.value = DetailUiState.Success(media)
                } else {
                    _uiState.value = DetailUiState.Error("Media dengan ID $id tidak ditemukan.")
                }
            } catch (e: Exception) {
                _uiState.value = DetailUiState.Error(
                    e.localizedMessage ?: "Gagal memuat detail. Periksa koneksi internet Anda."
                )
            }
        }
    }

    fun toggleFavorite() {
        val currentState = _uiState.value
        if (currentState is DetailUiState.Success) {
            viewModelScope.launch {
                val media = currentState.media
                if (_isFavorite.value) {
                    repository.removeFavorite(media.id)
                } else {
                    repository.saveFavorite(media)
                }
            }
        }
    }
}
