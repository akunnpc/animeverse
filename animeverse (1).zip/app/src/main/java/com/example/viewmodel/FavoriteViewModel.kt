package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.database.FavoriteEntity
import com.example.repository.AnimeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

class FavoriteViewModel(private val repository: AnimeRepository) : ViewModel() {
    private val _selectedFilter = MutableStateFlow("ALL") // ALL, ANIME, MANGA, MANHWA, MANHUA
    val selectedFilter = _selectedFilter.asStateFlow()

    // Expose filtered list reactively based on local database and active filter
    val favoritesState: StateFlow<List<FavoriteEntity>> = repository.getFavorites()
        .combine(_selectedFilter) { list, filter ->
            when (filter) {
                "ALL" -> list
                "ANIME" -> list.filter { it.type == "ANIME" }
                "MANGA" -> list.filter { it.type == "MANGA" && (it.countryOfOrigin == "JP" || it.countryOfOrigin == null) }
                "MANHWA" -> list.filter { it.type == "MANGA" && it.countryOfOrigin == "KR" }
                "MANHUA" -> list.filter { it.type == "MANGA" && it.countryOfOrigin == "CN" }
                else -> list
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun onFilterSelected(filter: String) {
        _selectedFilter.value = filter
    }
}
