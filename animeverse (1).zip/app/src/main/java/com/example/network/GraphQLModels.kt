package com.example.network

import com.example.model.Media
import com.example.model.PageInfo
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GraphQLRequest(
    val query: String,
    val variables: Map<String, Any?> = emptyMap()
)

@JsonClass(generateAdapter = true)
data class PageData(
    val pageInfo: PageInfo? = null,
    val media: List<Media>? = null
)

@JsonClass(generateAdapter = true)
data class GraphQLData(
    val Page: PageData? = null,
    val Media: Media? = null // For single detail page queries
)

@JsonClass(generateAdapter = true)
data class GraphQLError(
    val message: String
)

@JsonClass(generateAdapter = true)
data class GraphQLResponse(
    val data: GraphQLData? = null,
    val errors: List<GraphQLError>? = null
)
