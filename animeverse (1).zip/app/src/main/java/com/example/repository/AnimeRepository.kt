package com.example.repository

import com.example.database.FavoriteDao
import com.example.database.FavoriteEntity
import com.example.model.Media
import com.example.network.ApiClient
import com.example.network.GraphQLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

interface AnimeRepository {
    suspend fun getTrending(type: String?, page: Int = 1, perPage: Int = 12): List<Media>
    suspend fun getPopular(type: String?, page: Int = 1, perPage: Int = 12): List<Media>
    suspend fun getSeasonal(year: Int, season: String, page: Int = 1, perPage: Int = 12): List<Media>
    suspend fun getTopRated(type: String?, page: Int = 1, perPage: Int = 12): List<Media>
    suspend fun searchMedia(
        query: String,
        type: String?,
        format: String? = null,
        countryOfOrigin: String? = null,
        page: Int = 1,
        perPage: Int = 20
    ): List<Media>
    suspend fun getMediaDetail(id: Int): Media?

    // Favorites Room database access
    fun getFavorites(): Flow<List<FavoriteEntity>>
    fun isFavoriteFlow(id: Int): Flow<Boolean>
    suspend fun isFavorite(id: Int): Boolean
    suspend fun saveFavorite(media: Media)
    suspend fun removeFavorite(id: Int)
}

class AnimeRepositoryImpl(private val favoriteDao: FavoriteDao) : AnimeRepository {

    private val mediaListQuery = """
        query (${'$'}page: Int, ${'$'}perPage: Int, ${'$'}sort: [MediaSort], ${'$'}type: MediaType, ${'$'}season: MediaSeason, ${'$'}seasonYear: Int, ${'$'}search: String, ${'$'}country: CountryCode) {
          Page (page: ${'$'}page, perPage: ${'$'}perPage) {
            pageInfo {
              total
              currentPage
              lastPage
              hasNextPage
              perPage
            }
            media (sort: ${'$'}sort, type: ${'$'}type, season: ${'$'}season, seasonYear: ${'$'}seasonYear, search: ${'$'}search, countryOfOrigin: ${'$'}country) {
              id
              title {
                romaji
                english
                native
                userPreferred
              }
              coverImage {
                large
                medium
                color
              }
              bannerImage
              description
              type
              format
              status
              episodes
              chapters
              averageScore
              popularity
              favourites
              genres
              startDate {
                year
                month
                day
              }
              countryOfOrigin
            }
          }
        }
    """.trimIndent()

    private val mediaDetailQuery = """
        query (${'$'}id: Int) {
          Media (id: ${'$'}id) {
            id
            title {
              romaji
              english
              native
              userPreferred
            }
            coverImage {
              large
              medium
              color
            }
            bannerImage
            description
            type
            format
            status
            episodes
            chapters
            averageScore
            popularity
            favourites
            genres
            startDate {
              year
              month
              day
            }
            countryOfOrigin
            trailer {
              id
              site
            }
            studios(isMain: true) {
              nodes {
                name
              }
            }
            staff(perPage: 10) {
              edges {
                role
                node {
                  name {
                    full
                  }
                }
              }
            }
          }
        }
    """.trimIndent()

    override suspend fun getTrending(type: String?, page: Int, perPage: Int): List<Media> = withContext(Dispatchers.IO) {
        val variables = mutableMapOf<String, Any?>(
            "page" to page,
            "perPage" to perPage,
            "sort" to listOf("TRENDING_DESC", "POPULARITY_DESC")
        )
        if (type != null) variables["type"] = type

        val response = ApiClient.service.query(GraphQLRequest(mediaListQuery, variables))
        response.data?.Page?.media ?: emptyList()
    }

    override suspend fun getPopular(type: String?, page: Int, perPage: Int): List<Media> = withContext(Dispatchers.IO) {
        val variables = mutableMapOf<String, Any?>(
            "page" to page,
            "perPage" to perPage,
            "sort" to listOf("POPULARITY_DESC")
        )
        if (type != null) variables["type"] = type

        val response = ApiClient.service.query(GraphQLRequest(mediaListQuery, variables))
        response.data?.Page?.media ?: emptyList()
    }

    override suspend fun getSeasonal(year: Int, season: String, page: Int, perPage: Int): List<Media> = withContext(Dispatchers.IO) {
        val variables = mapOf(
            "page" to page,
            "perPage" to perPage,
            "sort" to listOf("POPULARITY_DESC"),
            "type" to "ANIME",
            "season" to season,
            "seasonYear" to year
        )

        val response = ApiClient.service.query(GraphQLRequest(mediaListQuery, variables))
        response.data?.Page?.media ?: emptyList()
    }

    override suspend fun getTopRated(type: String?, page: Int, perPage: Int): List<Media> = withContext(Dispatchers.IO) {
        val variables = mutableMapOf<String, Any?>(
            "page" to page,
            "perPage" to perPage,
            "sort" to listOf("SCORE_DESC")
        )
        if (type != null) variables["type"] = type

        val response = ApiClient.service.query(GraphQLRequest(mediaListQuery, variables))
        response.data?.Page?.media ?: emptyList()
    }

    override suspend fun searchMedia(
        query: String,
        type: String?,
        format: String?,
        countryOfOrigin: String?,
        page: Int,
        perPage: Int
    ): List<Media> = withContext(Dispatchers.IO) {
        val variables = mutableMapOf<String, Any?>(
            "page" to page,
            "perPage" to perPage,
            "sort" to listOf("POPULARITY_DESC")
        )
        if (query.isNotEmpty()) variables["search"] = query
        if (type != null) variables["type"] = type
        if (countryOfOrigin != null) variables["country"] = countryOfOrigin

        val response = ApiClient.service.query(GraphQLRequest(mediaListQuery, variables))
        response.data?.Page?.media ?: emptyList()
    }

    override suspend fun getMediaDetail(id: Int): Media? = withContext(Dispatchers.IO) {
        val variables = mapOf("id" to id)
        val response = ApiClient.service.query(GraphQLRequest(mediaDetailQuery, variables))
        response.data?.Media
    }

    // Favorites Room DAO Access
    override fun getFavorites(): Flow<List<FavoriteEntity>> = favoriteDao.getAllFavorites()

    override fun isFavoriteFlow(id: Int): Flow<Boolean> = favoriteDao.isFavoriteFlow(id)

    override suspend fun isFavorite(id: Int): Boolean = favoriteDao.isFavorite(id)

    override suspend fun saveFavorite(media: Media) = withContext(Dispatchers.IO) {
        val entity = FavoriteEntity(
            id = media.id,
            title = media.title?.getDisplayTitle() ?: "Untitled",
            subtitle = media.title?.romaji ?: media.title?.native,
            coverUrl = media.coverImage?.large ?: media.coverImage?.medium,
            bannerUrl = media.bannerImage,
            description = media.description,
            type = media.type ?: "ANIME",
            format = media.format,
            status = media.status,
            score = media.averageScore,
            episodes = media.episodes,
            chapters = media.chapters,
            genres = media.genres?.joinToString(","),
            studio = media.getStudio(),
            author = media.getAuthor(),
            artist = media.getArtist(),
            countryOfOrigin = media.countryOfOrigin
        )
        favoriteDao.insertFavorite(entity)
    }

    override suspend fun removeFavorite(id: Int) = withContext(Dispatchers.IO) {
        favoriteDao.deleteFavoriteById(id)
    }
}
