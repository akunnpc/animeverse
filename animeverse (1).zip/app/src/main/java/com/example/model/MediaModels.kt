package com.example.model

import androidx.compose.runtime.Immutable
import com.squareup.moshi.JsonClass

@Immutable
@JsonClass(generateAdapter = true)
data class PageInfo(
    val total: Int? = null,
    val currentPage: Int? = null,
    val lastPage: Int? = null,
    val hasNextPage: Boolean? = null,
    val perPage: Int? = null
)

@Immutable
@JsonClass(generateAdapter = true)
data class MediaTitle(
    val romaji: String? = null,
    val english: String? = null,
    val native: String? = null,
    val userPreferred: String? = null
) {
    fun getDisplayTitle(): String {
        return english ?: romaji ?: userPreferred ?: native ?: "Untitled"
    }
}

@Immutable
@JsonClass(generateAdapter = true)
data class CoverImage(
    val large: String? = null,
    val medium: String? = null,
    val color: String? = null
)

@Immutable
@JsonClass(generateAdapter = true)
data class MediaDate(
    val year: Int? = null,
    val month: Int? = null,
    val day: Int? = null
) {
    override fun toString(): String {
        if (year == null) return "Unknown"
        val m = month?.let { if (it < 10) "0$it" else "$it" } ?: "??"
        val d = day?.let { if (it < 10) "0$it" else "$it" } ?: "??"
        return "$year-$m-$d"
    }
}

@Immutable
@JsonClass(generateAdapter = true)
data class StudioNode(
    val name: String
)

@Immutable
@JsonClass(generateAdapter = true)
data class StudioConnection(
    val nodes: List<StudioNode>? = null
)

@Immutable
@JsonClass(generateAdapter = true)
data class Trailer(
    val id: String? = null,
    val site: String? = null
)

@Immutable
@JsonClass(generateAdapter = true)
data class StaffName(
    val full: String? = null
)

@Immutable
@JsonClass(generateAdapter = true)
data class StaffNode(
    val name: StaffName? = null
)

@Immutable
@JsonClass(generateAdapter = true)
data class StaffEdge(
    val role: String? = null,
    val node: StaffNode? = null
)

@Immutable
@JsonClass(generateAdapter = true)
data class StaffConnection(
    val edges: List<StaffEdge>? = null
)

@Immutable
@JsonClass(generateAdapter = true)
data class Media(
    val id: Int,
    val title: MediaTitle? = null,
    val coverImage: CoverImage? = null,
    val bannerImage: String? = null,
    val description: String? = null,
    val type: String? = null, // ANIME or MANGA
    val format: String? = null, // TV, MOVIE, MANGA, NOVEL, etc.
    val status: String? = null,
    val episodes: Int? = null,
    val chapters: Int? = null,
    val averageScore: Int? = null,
    val popularity: Int? = null,
    val favourites: Int? = null,
    val genres: List<String>? = null,
    val startDate: MediaDate? = null,
    val countryOfOrigin: String? = null, // JP, KR, CN
    val trailer: Trailer? = null,
    val studios: StudioConnection? = null,
    val staff: StaffConnection? = null
) {
    fun getDisplayType(): String {
        if (type == "ANIME") return "Anime"
        return when (countryOfOrigin) {
            "KR" -> "Manhwa"
            "CN" -> "Manhua"
            else -> "Manga"
        }
    }

    fun getAuthor(): String? {
        val candidates = listOf("Story", "Original Creator", "Author", "Writer")
        // Check for specific roles in edges
        staff?.edges?.forEach { edge ->
            val role = edge.role ?: ""
            if (candidates.any { role.contains(it, ignoreCase = true) }) {
                edge.node?.name?.full?.let { return it }
            }
        }
        return staff?.edges?.firstOrNull()?.node?.name?.full
    }

    fun getArtist(): String? {
        val candidates = listOf("Art", "Illustrator", "Artist", "Draw")
        staff?.edges?.forEach { edge ->
            val role = edge.role ?: ""
            if (candidates.any { role.contains(it, ignoreCase = true) }) {
                edge.node?.name?.full?.let { return it }
            }
        }
        return null
    }

    fun getStudio(): String? {
        return studios?.nodes?.firstOrNull()?.name
    }
}
