package com.example.utils

import java.util.Calendar

object SeasonUtils {
    enum class AnimeSeason {
        WINTER, SPRING, SUMMER, FALL
    }

    fun getCurrentSeason(): AnimeSeason {
        val calendar = Calendar.getInstance()
        val month = calendar.get(Calendar.MONTH) // 0-11
        return when (month) {
            Calendar.JANUARY, Calendar.FEBRUARY, Calendar.MARCH -> AnimeSeason.WINTER
            Calendar.APRIL, Calendar.MAY, Calendar.JUNE -> AnimeSeason.SPRING
            Calendar.JULY, Calendar.AUGUST, Calendar.SEPTEMBER -> AnimeSeason.SUMMER
            else -> AnimeSeason.FALL
        }
    }

    fun getCurrentYear(): Int {
        return Calendar.getInstance().get(Calendar.YEAR)
    }

    fun getSeasonLabel(season: AnimeSeason): String {
        return when (season) {
            AnimeSeason.WINTER -> "Winter"
            AnimeSeason.SPRING -> "Spring"
            AnimeSeason.SUMMER -> "Summer"
            AnimeSeason.FALL -> "Fall"
        }
    }
}
