package com.example.theme

import androidx.compose.ui.graphics.Color

// Light Palette (Warm high density standard M3 theme)
val LightPrimary = Color(0xFF6750A4)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFEADDFF)
val LightOnPrimaryContainer = Color(0xFF21005D)
val LightSecondary = Color(0xFF625B71)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightBackground = Color(0xFFFEF7FF)
val LightSurface = Color(0xFFFEF7FF)
val LightOnBackground = Color(0xFF1D1B20)
val LightOnSurface = Color(0xFF1D1B20)

// Dark Palette (High Density Midnight Lavender M3 dark mode)
val DarkPrimary = Color(0xFFD0BCFF)
val DarkOnPrimary = Color(0xFF381E72)
val DarkPrimaryContainer = Color(0xFF4F378B)
val DarkOnPrimaryContainer = Color(0xFFEADDFF)
val DarkSecondary = Color(0xFFCCC2DC)
val DarkOnSecondary = Color(0xFF332D41)
val DarkBackground = Color(0xFF1C1B1F) // Deep M3 dark grey
val DarkSurface = Color(0xFF1C1B1F)    // Dark background aligned
val DarkOnBackground = Color(0xFFE6E1E5)
val DarkOnSurface = Color(0xFFE6E1E5)

// Custom tag colors styled elegantly with High Density palette
val TagAnime = Color(0xFFD0BCFF) // Highlight Purple
val TagManga = Color(0xFFCCC2DC) // Muted lavender
val TagManhwa = Color(0xFFEFB8C8) // Pink highlight
val TagManhua = Color(0xFFE8DEF8) // Accent container tint
