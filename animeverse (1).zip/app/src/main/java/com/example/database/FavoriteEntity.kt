package com.example.database

import androidx.compose.runtime.Immutable
import androidx.room.Entity
import androidx.room.PrimaryKey

@Immutable
@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val id: Int,
    val title: String,
    val subtitle: String? = null,
    val coverUrl: String? = null,
    val bannerUrl: String? = null,
    val description: String? = null,
    val type: String, // ANIME or MANGA
    val format: String? = null,
    val status: String? = null,
    val score: Int? = null,
    val episodes: Int? = null,
    val chapters: Int? = null,
    val genres: String? = null, // Comma separated list of genres
    val studio: String? = null,
    val author: String? = null,
    val artist: String? = null,
    val countryOfOrigin: String? = null,
    val savedAt: Long = System.currentTimeMillis()
)
