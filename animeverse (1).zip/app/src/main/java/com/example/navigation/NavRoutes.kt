package com.example.navigation

object NavRoutes {
    const val HOME = "home"
    const val SEARCH = "search"
    const val FAVORITE = "favorite"
    const val DETAIL = "detail/{mediaId}"

    fun createDetailRoute(mediaId: Int): String {
        return "detail/$mediaId"
    }
}
